#include "Player.h"
#include "Game.h"


void Player::Render()
{
	SDL_RenderCopy(Game::GetGame()->GetRen(), Tile::tShip, NULL, &this->rect);
	//SDL_SetRenderDrawColor(r, 0, 255, 255, 255);
	//SDL_RenderFillRect(r, &rect);
}

void Player::MoveToDest()
{
	SetPos(ChooseDest()->GetPos());
	
}


Tile* Player::ChooseDest()
{
	Tile* temp = adjacent[0];
	
	for(Tile* t : adjacent)
	{
		if (t->GetWeight() < temp->GetWeight())
		{
			temp = t;
		}
	}
	
	
	return temp;
}


void Player::GetAdjacent()
{
	adjacent[0] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->up();
	adjacent[1] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->down();
	adjacent[2] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->left();
	adjacent[3] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->right();

}