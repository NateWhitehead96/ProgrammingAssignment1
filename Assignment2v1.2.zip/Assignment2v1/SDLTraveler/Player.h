#pragma once
#include "SDL.h"
#include <iostream>
#include "Tile.h"
class Player
{

private:
	SDL_Rect rect = { 0,0,30,30 };

	Tile* adjacent[4];
	SDL_Point startLoc;
	SDL_Point mLoc;

public:

	Player()
	{
		//mLoc.x = 1 + rand() % 20;
		//mLoc.y = 1 +  rand() % 15;

		mLoc.x = 2;
		mLoc.y = 4;


		rect.x = (mLoc.x * 40) + 5;
		rect.y = (mLoc.y * 40) + 5;

		startLoc = mLoc;

		
	}

	void Update()
	{
		rect.x = (mLoc.x * 40) + 5;
		rect.y = (mLoc.y * 40) + 5;
	}

	void MoveToDest();

	Tile* ChooseDest();
	void GetAdjacent();

	SDL_Point GetLoc()
	{
		return mLoc;
	}
	void SetPos(SDL_Point p)
	{
		mLoc = p;
	}

	void Reset()
	{
		rect.x = ((rand() % 20) * 40) + 5;
		rect.y = ((rand() % 15) * 40) + 5;
	}

	void Render();

};

