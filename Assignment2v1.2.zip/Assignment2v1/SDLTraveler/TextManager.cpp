#include "TextManager.h"
#include "Game.h"

TextManager* TextManager::Texter = nullptr;

TextManager* TextManager::GetTexter()
{
	if (Texter == nullptr)
	{
		Texter = new TextManager;
	}
	return Texter;
}

TextManager::TextManager()
{
	font1 = TTF_OpenFont("Consolas.ttf", 30);
}

SDL_Texture* TextManager::GetText(const char* t)
{

	SDL_Color black = { 0,0,0 };

	SDL_Surface* tSurface = TTF_RenderText_Solid(font1, t, black);

	SDL_Texture* tTexture = SDL_CreateTextureFromSurface(Game::GetGame()->GetRen(), tSurface);

	return tTexture;
}
