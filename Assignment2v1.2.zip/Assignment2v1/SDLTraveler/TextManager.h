#pragma once
#include <vector>
#include "SDL.h"
#include <iostream>
#include "SDL_image.h"
#include "SDL_ttf.h"
class TextManager
{
private:
	static TextManager* Texter;
	
	std::vector<SDL_Texture*> texts;

	TextManager();

	TTF_Font* font1;

public:
	static TextManager* GetTexter();

	SDL_Texture* GetText(const char* t);


};

