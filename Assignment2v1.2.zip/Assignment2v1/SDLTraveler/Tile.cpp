#include "Tile.h"
#include "Game.h"
#include "TextManager.h"
#include <cstring>
#include <sstream>
#include <iomanip>
#include <iostream>
using namespace std;

SDL_Texture* Tile::tAst;
SDL_Texture* Tile::tGoal;
SDL_Texture* Tile::tShip;





void Tile::SetWeight(int f)
{
	weightVal = f;
	std::string num2 = std::to_string(f);
	weight = TextManager::GetTexter()->GetText(num2.c_str());
}


void Tile::SetWeight(float f)
{
	//float f = ios.precision(f,3);
	//string num2 = to_string(f);
	//stringstream stream;
	//stream << setprecision(1) << f << endl;
	//std::string num2 = std::to_string(f);
	//string num = stream.str();
	string num = to_string(f);
	weight = TextManager::GetTexter()->GetText( num.c_str() );
}



void Tile::Render()
{
	if (mState == OPEN)
	{
		SDL_SetRenderDrawColor(Game::GetGame()->GetRen(), 0, 255, 0, 255);
		SDL_RenderDrawRect(Game::GetGame()->GetRen(), &rect);
	}
	if (mState == CLOSED)
	{

		SDL_SetRenderDrawColor(Game::GetGame()->GetRen(), 255, 0, 0, 255);
		SDL_RenderFillRect(Game::GetGame()->GetRen(), &rect);
	}
	if (mState == OBSTACLE)
	{

		SDL_RenderCopy(Game::GetGame()->GetRen(), tAst, NULL, &rect);
		//SDL_SetRenderDrawColor(r, 0, 0, 255, 255);
		//SDL_RenderFillRect(r, &rect);
	}

	if (weight != nullptr)
	{
		SDL_RenderCopy(Game::GetGame()->GetRen(), weight, NULL, &label);
	}
}

Tile* Tile::up()
{
	
	return Game::GetGame()->GetTile(xPos, yPos - 1);
	
	
}

Tile* Tile::down()
{
	
	return Game::GetGame()->GetTile(xPos, yPos + 1);
	

}

Tile* Tile::right()
{
	
	return Game::GetGame()->GetTile(xPos + 1, yPos);
	
}

Tile* Tile::left()
{
	
	return Game::GetGame()->GetTile(xPos - 1, yPos);
	
}