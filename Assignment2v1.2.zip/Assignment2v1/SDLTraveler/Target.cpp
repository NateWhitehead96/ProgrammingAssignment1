#include "Target.h"
#include "Game.h"

void Target::Render()
{
	SDL_RenderCopy(Game::GetGame()->GetRen(), Tile::tGoal, NULL, &this->rect);
	//SDL_SetRenderDrawColor(r, 255, 0, 255, 255);
	//SDL_RenderFillRect(r, &rect);
}
