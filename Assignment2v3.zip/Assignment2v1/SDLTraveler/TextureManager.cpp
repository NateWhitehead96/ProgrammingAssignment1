#include "TextureManager.h"

TextureManager* TextureManager::Instance;


TextureManager* TextureManager::GetInstance()
{
	if (Instance == nullptr)
	{
		static TextureManager* Instance = new TextureManager;
	}
	return Instance;
}

SDL_Texture* TextureManager::GetTexture(int n)
{
	return pTexture[n];
}



void TextureManager::LoadTexture(const char* s)
{
	SDL_Surface* pSurface;
	//SDL_Texture* pTexture;
	pSurface = IMG_Load(s);
	if (pSurface == nullptr)
	{
		std::cout << s << "SURFACE FAIL \n\n";
	}
	//pTexture.push_back = SDL_CreateTextureFromSurface(Game::GetGame()->GetRen(), pSurface);
	pTexture[numTextures] = SDL_CreateTextureFromSurface(Game::GetGame()->GetRen(), pSurface);
	numTextures++;
	if (pTexture[numTextures] == nullptr)
	{
		std::cout << s << "SURFACE FAIL \n\n";
	}

}
