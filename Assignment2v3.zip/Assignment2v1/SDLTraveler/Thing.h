#pragma once
#include "SDL.h"
#include "SDL_image.h"
#include "TextureManager.h"
class Thing
{
private:
	SDL_Rect rSrc = { 0,0,0,0 };
	SDL_Rect rDst = { 0,0,0,0 };
	SDL_Texture* Texture = nullptr;
	SDL_Point vel = { 0,0 };

	int textureIndex = 999;

	int angle = 0;
	SDL_RendererFlip flip = SDL_FLIP_NONE;

public:
	Thing(int sx, int sy, int sw, int sh, int dx, int dy, int dw, int dh)
	{
		rSrc = { sx, sy, sw, sh };
		rDst = { dx, dy, dw, dh };
	}

	void Update()
	{
		rDst.x += vel.x;
		rDst.y += vel.y;
	}

	void SetTexture(SDL_Texture* t)
	{
		Texture = t;
	}
	void SetTexture(const char* s)
	{
		TextureManager::GetInstance()->LoadTexture(s);
		textureIndex = TextureManager::GetInstance()->getNum();
	}

	SDL_Texture* GetTexture()
	{
		return TextureManager::GetInstance()->GetTexture(textureIndex);
	}

	void Render()
	{
		SDL_RenderCopy(Game::GetGame()->GetRen(), GetTexture(), &rSrc, &rDst);
	}

	void RenderEx()
	{
		SDL_RenderCopyEx(Game::GetGame()->GetRen(), GetTexture(), &rSrc, &rDst, angle, NULL, flip);
	}

	~Thing() {}
};

