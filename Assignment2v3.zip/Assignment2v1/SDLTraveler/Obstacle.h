#pragma once
#include "Tile.h"
class Obstacle : public Tile
{

};

