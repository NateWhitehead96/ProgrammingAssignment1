#pragma once

#include "AudioManager.h"
#include "TextureManager.h"
#include "TextManager.h"

#include <iostream>
#include <fstream>
#include "SDL.h"
#include "SDL_image.h"
#include "SDL_mixer.h"
#include "Tile.h"
#include "SDL_ttf.h"
#include "Player.h"
#include "Target.h"
#include <string>
#include <ctime>
#include <vector>


using namespace std;

class Game
{
private:
	
	static Game* Instance;
	Game();
	bool gameOn = true;

	// SDL stuff

	SDL_Window* pWindow = nullptr;
	SDL_Renderer* pRenderer = nullptr;
	

	SDL_Texture* tAsteroid;
	SDL_Texture* tGoal;
	SDL_Texture* tShip;

	Tile* mAsteroids[21];
	Tile* tStart;

	bool hasArrived = false;

	SDL_Surface* pSurface;

	SDL_Point pGoal;
	SDL_Point pStart;

	SDL_GameController* controller1 = nullptr;
	SDL_Event event;
	SDL_RendererFlip flip = SDL_FLIP_NONE;

	int startQuad = 0;
	
	Tile* mGrid[17][22];

	/*vector<Tile*> mOpen;
	vector<Tile*> mClosed;
	vector<Tile*> mPath;*/


	Player mPlayer;
	Target mTarget;

	const char* testText = "Test" ;
	SDL_Texture* text = nullptr;

	int m_pathLength = 0;

	bool starting = true;
	bool launched = false;

public:
	static Game* GetGame();

	SDL_Renderer* GetRen()
	{
		return pRenderer;
	}

	Tile* GetTile(int x, int y);
	void Init();

	int Manhattan(SDL_Point goal, SDL_Point tile)
	{
		int x = abs((goal.x - tile.x));
	
		int y = abs((goal.y - tile.y));
		
		return (x + y);

	}

	bool GetStart()
	{
		return starting;
	}

	void endStart()
	{
		starting = false;
	}

	void findShortestPath();

	void moveShipAlong();

	int AugmentedManhattan(SDL_Point goal, SDL_Point tile, SDL_Point origin)
	{
		int x = abs((goal.x - tile.x) * 100);
		int y = abs((goal.y - tile.y) * 100);
		
		float aX = abs((origin.x - tile.x) );
		float aY = abs((origin.y - tile.y) );
		//cout << aX << endl << aY << endl;

		x = x - aX;
		y = y - aY;

		
		return (x + y);
	}

	void SetQuad(int n)
	{
		startQuad = n;
	}

	void HandleEvents();

	void Update();

	void Render();

	void Clean();

	bool Over();

	bool Start();

	void Reset();

	bool endGame()
	{
		if (gameOn == true)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	~Game();
};

