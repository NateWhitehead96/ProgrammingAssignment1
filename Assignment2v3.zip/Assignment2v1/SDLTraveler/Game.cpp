#include "Game.h"
#include "AudioManager.h"
using namespace std;

Game::Game()
{
}

Game* Game::Instance = nullptr;
Game* Game::GetGame()
{
	if (Instance == nullptr)
	{
		Instance = new Game;
	}
	return Instance;
}

Tile* Game::GetTile(int x, int y)
{
	return mGrid[y][x];
}

void Game::Init()
{
	srand(time(NULL));

	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_JoystickEventState(SDL_ENABLE);
	SDL_JoystickUpdate();
	cout << SDL_NumJoysticks();

	for (int i = 0; i < SDL_NumJoysticks(); i++)
	{
		if (SDL_IsGameController(i))
		{
			controller1 = SDL_GameControllerOpen(i);
			cout << "SUCCESS! HUZZAH!";
		}
		else cout << "FAIL! FUFFAH!";
	}

	pWindow = SDL_CreateWindow("Window", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 880, 680, 0);
	pRenderer = SDL_CreateRenderer(pWindow, -1, 0);

	//Controller

	// TEXT STUFF ====================
	TTF_Init();


	// END TEXT STUFF ================
	// END TEXT STUFF ================================================================



	SDL_SetRenderDrawColor(pRenderer, 200, 200, 200, 255);
	SDL_RenderClear(pRenderer);

	// Okay,  now let's try inputs.

	Mix_VolumeMusic(100);
	Mix_Volume(-1, 128);

	//Mix_PlayMusic(sMusic, -1);

	AudioManager::GetInstance()->Music1();

	// Load in textures

	pSurface = IMG_Load("Asteroid.png");
	tAsteroid = SDL_CreateTextureFromSurface(pRenderer, pSurface);
	SDL_FreeSurface(pSurface);

	pSurface = IMG_Load("Goal.png");
	tGoal = SDL_CreateTextureFromSurface(pRenderer, pSurface);
	SDL_FreeSurface(pSurface);

	pSurface = IMG_Load("Ship.png");
	tShip = SDL_CreateTextureFromSurface(pRenderer, pSurface);
	SDL_FreeSurface(pSurface);

	Tile::TileInit(tAsteroid, tGoal, tShip);

	// Set up tiles

	for (int col = 0; col < 22; col++)
	{
		for (int row = 0; row < 17; row++)
		{
			mGrid[row][col] = new Tile;
			mGrid[row][col]->SetTile(col, row);
		}
	}


	mAsteroids[0] = mGrid[2][8];
	mAsteroids[1] = mGrid[6][3];
	mAsteroids[2] = mGrid[6][4];
	mAsteroids[3] = mGrid[6][6];
	mAsteroids[4] = mGrid[6][7];
	mAsteroids[5] = mGrid[6][8];
	mAsteroids[6] = mGrid[6][9];
	mAsteroids[7] = mGrid[6][10];
	mAsteroids[8] = mGrid[7][12];
	mAsteroids[9] = mGrid[7][13];
	mAsteroids[10] = mGrid[7][14];
	mAsteroids[11] = mGrid[9][5];
	mAsteroids[12] = mGrid[9][6];
	mAsteroids[13] = mGrid[11][8];
	mAsteroids[14] = mGrid[13][8];

	mAsteroids[15] = mGrid[5][15];
	mAsteroids[16] = mGrid[5][16];
	mAsteroids[17] = mGrid[5][17];
	mAsteroids[18] = mGrid[5][18];

	mAsteroids[19] = mGrid[11][2];
	mAsteroids[20] = mGrid[11][3];
	mAsteroids[21] = mGrid[11][4];

	//int starterSeed = rand() % 3;
	
	/*
		switch (startQuad)
		{
		case 1:
			playerStart = { 3,2 };
			mPlayer.Spawn(playerStart);
			break;
		case 2:
			playerStart = { 16,3 };
			mPlayer.Spawn(playerStart);
			break;
		case 3:
			playerStart = { 4, 12 };
			mPlayer.Spawn(playerStart);
			break;

		}
	*/



	





	//text = TextManager::GetTexter()->GetText(pRenderer, testText);
	pGoal = mTarget.GetLoc();
	pStart = mPlayer.GetLoc();
	
	SDL_Point targetLoc = mTarget.GetLoc();

	mGrid[targetLoc.y][targetLoc.x]->SetState(Tile::GOAL);

	for (int col = 1; col < 21; col++)
	{
		for (int row = 1; row < 16; row++)
		{
			if (mGrid[row][col]->GetState() == Tile::OPEN)
			{
				SDL_Point temp = { col, row };
				//mGrid[row][col]->SetWeight( Manhattan(pGoal, temp));
				mGrid[row][col]->SetWeight(AugmentedManhattan(pGoal, temp, pStart));
			}
		}
	}

	for (int i = 0; i < 21; i++)
	{
		mAsteroids[i]->SetState(Tile::OBSTACLE);
		mAsteroids[i]->SetWeight(9001);

	}
	for (int i = 0; i < 22; i++)
	{
		mGrid[0][i]->SetWeight(9001);
		mGrid[16][i]->SetWeight(9001);

	}

	for (int i = 1; i < 16; i++)
	{
		mGrid[i][0]->SetWeight(9001);
		mGrid[i][21]->SetWeight(9001);

	}

	AudioManager::GetInstance()->Music1();
}

//void Game::findShortestPath()
//{
//	mPath.push_back(mPlayer.ChooseDest());
//}

//void Game::moveShipAlong()
//{
//	if (m_pathLength < mOpen.size())
//	{
//		mPlayer.SetPos(mOpen[m_pathLength]->GetPos());
//		m_pathLength++;
//	}
//}

void Game::HandleEvents()
{

	while (SDL_PollEvent(&event))
	{
		if (event.type == SDL_KEYDOWN)
		{
			if (event.key.keysym.sym == SDLK_ESCAPE || event.key.keysym.sym == SDLK_x)
			{
				gameOn = false;
			}
		}
		
	}

}

void Game::Update()
{
	SDL_SetRenderDrawColor(pRenderer, 255, 255, 255, 255);
	
	if (launched == false)
	{
		SDL_Point playerStart;
		if (startQuad == 1)
		{
			playerStart = { 2,4 };
			mPlayer.Spawn(playerStart);
		}
		if (startQuad == 2)
		{
			playerStart = { 12,3 };
			mPlayer.Spawn(playerStart);
		}
		if (startQuad == 3)
		{
			playerStart = { 4, 13 };
			mPlayer.Spawn(playerStart);

		}

			launched = true;
	}

	SDL_Point playerCheck = mPlayer.GetLoc();
	if (mGrid[playerCheck.y][playerCheck.x]->GetState() != Tile::GOAL)
	{
		SDL_Delay(1000);
		mPlayer.GetAdjacent();
		mPlayer.MoveToDest();

		AudioManager::GetInstance()->Move();
	}
	else
	{
		if (hasArrived == false)
		{
			AudioManager::GetInstance()->Arrive();
			hasArrived = true;
		}
	}

	mPlayer.Update();

	SDL_RenderClear(pRenderer);

}

void Game::Render()
{
	
	for (int col = 0; col < 22; col++)
	{
		for (int row = 0; row < 17; row++)
		{
			mGrid[row][col]->Render();
		}
	}

	//SDL_RenderCopy(pRenderer, text, NULL, NULL);
	
	mTarget.Render();
	mPlayer.Render();


	SDL_RenderPresent(pRenderer);
}

bool Game::Start()
{
	bool playAgain = false;

	while (SDL_PollEvent(&event))
	{



		return playAgain;
	}
}

bool Game::Over()
{

	bool choice = false;
	bool playAgain = true;

	while (choice == false)
	{
		
		SDL_RenderClear(pRenderer);
		
		
		SDL_RenderPresent(pRenderer);

		while (SDL_PollEvent(&event))
		{

		}

	}
	return playAgain;

}

void Game::Reset()
{
	
}

void Game::Clean()
{
	SDL_DestroyWindow(pWindow);
	SDL_DestroyRenderer(pRenderer);
	//SDL_DestroyTexture(pTexture);
	
	SDL_Quit();

}


Game::~Game()
{
}
