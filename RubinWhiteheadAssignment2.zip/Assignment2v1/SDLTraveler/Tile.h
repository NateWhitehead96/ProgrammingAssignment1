#pragma once
#include "SDL.h"
//#include "Game.h"
#include "TextManager.h"
#include "SDL_image.h"
//#include "TextureManager.h"
#include <string>
#include <cstring>
#include <iostream>

class Tile
{
public:

	enum States {OPEN, CLOSED, OBSTACLE, GOAL};
	static SDL_Texture* tAst;
	static SDL_Texture* tGoal;
	static SDL_Texture* tShip;
	static void TileInit(SDL_Texture* a, SDL_Texture* g, SDL_Texture* s)
	{
		tAst = a;
		tGoal = g;
		tShip = s;
	}

	Tile()
	{
		
	}

	Tile(int x, int y)
	{
		rect.x = 40 * x;
		rect.y = 40 * y;

		xPos = x;
		yPos = y;

		
	}

	void Revert();

	Tile* up();
	
	Tile* down();
	
	Tile* right();
	
	Tile* left();

	void SetWeight(int f);
	void SetWeight(float f);

	void SetWeight(int f, bool b);

	void SetTile(int x, int y)
	{
		rect.x = 40 * x;
		rect.y = 40 * y;

		label.x = rect.x + 5;
		label.y = rect.y + 5;

		xPos = x;
		yPos = y;

		mLoc.x = x;
		mLoc.y = y;
	}

	States GetState()
	{
		return mState;
	}

	void SetState(States s)
	{
		mState = s;
	}

	int GetWeight()
	{
		return weightVal;
	}

	void Render();

	SDL_Point GetPos()
	{
		return mLoc;
	}
	void SetPos(int y, int x)
	{
		mLoc.x = x;
		mLoc.y = y;
	}


private:
	SDL_Rect rect = { 0,0,40,40 };
	SDL_Rect label = { 0,0, 30, 15 };

	SDL_Texture* weight = nullptr;

	int xPos = 0;
	int yPos = 0;

	SDL_Point mLoc = { 0,0 };

	int weightVal = 0;
	int startWeight = 0;

	States mState = OPEN;
};

