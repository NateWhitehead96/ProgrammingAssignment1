#pragma once
#include "SDL.h"
#include "TextManager.h"
class TextBox
{
private:
	SDL_Rect dest = { 966, 0, 64, 64 };
	SDL_Texture* text = nullptr;

public:



	void SetPosition(int y);

	void SetWidth(int w)
	{
		dest.w = w;
	}

	void Update(int);

	
	void Render();

	TextBox(int n);

	~TextBox(){}

};

