#include "Player.h"
#include "Game.h"


void Player::Render()
{
	SDL_RenderCopy(Game::GetGame()->GetRen(), Tile::tShip, NULL, &this->rect);

}

void Player::MoveToDest()
{
	tilesSoFar++;
	weightSoFar += (Game::GetGame()->GetTile(mLoc.x, mLoc.y)->GetWeight());


	lastLoc = mLoc;

	mPath.push_back(Game::GetGame()->GetTile(mLoc.x, mLoc.y));

	
	SetPos(ChooseDest()->GetPos());
	
}

void Player::WinningPath()
{
	for (Tile* t : mPath)
	{
		t->SetWeight(0);
		
	}
}

void Player::OpenPath()
{

	for (Tile* t : mPath)
	{
		t->SetState(Tile::OPEN);
		t->Revert();
	}

	lastLoc = { -1,-1 };
}

void Player::ClosePrevious()
{


	if (lastLoc.x != -1)
	{
		
		Game::GetGame()->GetTile(lastLoc.x, lastLoc.y)->SetState(Tile::CLOSED);
		Game::GetGame()->GetTile(lastLoc.x, lastLoc.y)->SetWeight(9000);
	}
}

Tile* Player::ChooseDest()
{
	Tile* temp = adjacent[0];
	
	for(Tile* t : adjacent)
	{
		if (t->GetWeight() < temp->GetWeight())
		{
			temp = t;
		}
		else if (t->GetWeight() == temp->GetWeight())
		{
			int coin = rand() % 2;
			
			if (coin == 0)
			{
				temp = t;
			}

		}
	}
	
	
	return temp;
}


void Player::GetAdjacent()
{
	if (bias == 0)
	{
		adjacent[0] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->up();
		adjacent[3] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->down();
		adjacent[1] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->left();
		adjacent[2] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->right();
	}

	if (bias == 1)
	{
		adjacent[2] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->up();
		adjacent[1] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->down();
		adjacent[3] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->left();
		adjacent[0] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->right();
	}

	if (bias == 2)
	{
		adjacent[2] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->up();
		adjacent[3] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->down();
		adjacent[0] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->left();
		adjacent[1] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->right();
	}

	if (bias == 3)
	{
		adjacent[3] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->up();
		adjacent[0] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->down();
		adjacent[1] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->left();
		adjacent[2] = Game::GetGame()->GetTile(mLoc.x, mLoc.y)->right();
	}
}