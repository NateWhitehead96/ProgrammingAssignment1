#include "Start.h"
#include "Game.h"
#include "TextManager.h"
#include <iostream>

Start::Start()
{
	pSurf = IMG_Load("Start_Screen.png");
	tBG = SDL_CreateTextureFromSurface(Game::GetGame()->GetRen(), pSurf);
	SDL_FreeSurface(pSurf);

	const char* clickText = "CLICK TO BEGIN";

	ClickHere = TextManager::GetTexter()->GetText(clickText);



}


void Start::Render()
{
	if (selectScreen == false)
	{
		//SDL_RenderClear(Game::GetGame()->GetRen());
		SDL_RenderCopy(Game::GetGame()->GetRen(), tBG, NULL, NULL);

		while (SDL_PollEvent(&event))
		{
			if (event.type == SDL_MOUSEBUTTONDOWN)
			{
				selectScreen = true;
			}
		}
	}
	else
	{
		while (SDL_PollEvent(&event))
		{
			SDL_GetMouseState(&mouse.x, &mouse.y);

			if (event.type == SDL_MOUSEBUTTONDOWN)
			{
				if (startQuad > 0)
				{
					std::cout << "StartQuad: " << startQuad << endl;
					Game::GetGame()->SetQuad(startQuad);
					Game::GetGame()->endStart();
					Game::GetGame()->Restart();

				}
			}

		}


			SDL_SetRenderDrawColor(Game::GetGame()->GetRen(), 0, 0, 0, 255);
			SDL_RenderClear(Game::GetGame()->GetRen());

			if (SDL_PointInRect(&mouse, &Q1))
			{
				SDL_SetRenderDrawColor(Game::GetGame()->GetRen(), 255, 0, 0, 255);
				SDL_RenderFillRect(Game::GetGame()->GetRen(), &Q1);
				startQuad = 1;
			}
			else
			{
				SDL_SetRenderDrawColor(Game::GetGame()->GetRen(), 0, 0, 255, 255);
				SDL_RenderFillRect(Game::GetGame()->GetRen(), &Q1);
			}


			if (SDL_PointInRect(&mouse, &Q2))
			{
				SDL_SetRenderDrawColor(Game::GetGame()->GetRen(), 255, 0, 0, 255);
				SDL_RenderFillRect(Game::GetGame()->GetRen(), &Q2);

				startQuad = 2;
			}
			else
			{
				SDL_SetRenderDrawColor(Game::GetGame()->GetRen(), 0, 0, 255, 255);
				SDL_RenderFillRect(Game::GetGame()->GetRen(), &Q2);
			}

			if (SDL_PointInRect(&mouse, &Q3))
			{
				SDL_SetRenderDrawColor(Game::GetGame()->GetRen(), 255, 0, 0, 255);
				SDL_RenderFillRect(Game::GetGame()->GetRen(), &Q3);

				startQuad = 3;	
			}
			else
			{
				SDL_SetRenderDrawColor(Game::GetGame()->GetRen(), 0, 0, 255, 255);
				SDL_RenderFillRect(Game::GetGame()->GetRen(), &Q3);
			}

		

	}

	SDL_RenderPresent(Game::GetGame()->GetRen());

}
