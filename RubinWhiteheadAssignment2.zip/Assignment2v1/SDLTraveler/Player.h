#pragma once
#include "SDL.h"
#include <iostream>
#include <vector>
#include "Tile.h"
class Player
{

private:
	SDL_Rect rect = { 0,0,30,30 };

	Tile* adjacent[4];
	std::vector <Tile*> mPath; 

	SDL_Point startLoc;
	SDL_Point mLoc = {-1,-1};
	SDL_Point lastLoc = {-1,-1};

	int bias = 0;

	int tilesSoFar = 0;

	int weightSoFar = 0;

public:
	void Spawn(SDL_Point p)
	{
		mLoc = p;


		rect.x = (mLoc.x * 40) + 5;
		rect.y = (mLoc.y * 40) + 5;

		startLoc = mLoc;

	}

	void WinningPath();
	void OpenPath();

	void ClosePrevious();

	int GetTSF()
	{
		return tilesSoFar;
	}

	int GetWSF()
	{
		return weightSoFar;
	}

	void SetBias(int n)
	{
		bias = n;
	}

	Player()
	{
		//mLoc.x = 1 + rand() % 20;
		//mLoc.y = 1 +  rand() % 15;

		mLoc.x = 2;
		mLoc.y = 4;


		rect.x = (mLoc.x * 40) + 5;
		rect.y = (mLoc.y * 40) + 5;

		startLoc = mLoc;

		
	}

	void Update()
	{
		rect.x = (mLoc.x * 40) + 5;
		rect.y = (mLoc.y * 40) + 5;
	}

	void MoveToDest();

	Tile* ChooseDest();
	void GetAdjacent();

	SDL_Point GetLoc()
	{
		return mLoc;
	}
	void SetPos(SDL_Point p)
	{
		mLoc = p;
	}

	void Reset()
	{
		rect.x = ((rand() % 20) * 40) + 5;
		rect.y = ((rand() % 15) * 40) + 5;
	}

	void Render();

};

