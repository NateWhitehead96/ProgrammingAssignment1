#include "TextBox.h"
#include "Game.h"

void TextBox::SetPosition(int y)
{
	dest.y = y;
}

void TextBox::Update(int n)
{
	std::string num2 = std::to_string(n);
	text = TextManager::GetTexter()->GetText(num2.c_str());
}

void TextBox::Render()
{
	SDL_RenderCopy(Game::GetGame()->GetRen(), text, NULL, &dest);
}

TextBox::TextBox(int n)
{
	std::string num2 = std::to_string(n);
	text = TextManager::GetTexter()->GetText(num2.c_str());
}
