#pragma once
#include "SDL.h"
#include <iostream>
#include "Tile.h"
class Target : public Tile
{
private:
	SDL_Rect rect = { 0,0,30,30 };
	
	SDL_Point mLoc;

public:

	Target()
	{
		//mLoc.x = (rand() % 20);
		//mLoc.y = (rand() % 15);

		mLoc.x = 17;
		mLoc.y = 11;

		rect.x = (mLoc.x * 40) + 5;
		rect.y = (mLoc.y * 40) + 5;

		
	}

	SDL_Point GetLoc()
	{
		return mLoc;
	}

	void Reset()
	{
		rect.x = ((rand() % 20) * 40) + 5;
		rect.y = ((rand() % 15) * 40) + 5;
	}

	void Render();

};

