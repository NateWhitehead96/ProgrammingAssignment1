#pragma once
#include <iostream>
#include "SDL.h"
#include "SDL_image.h"
#include "Game.h"
#include <vector>
class TextureManager
{
private:
	TextureManager() {}
	static TextureManager* Instance;

	
	SDL_Texture* pTexture[20];
//	vector<SDL_Texture*> pTexture;
	SDL_Surface* pSurface = nullptr;

	int numTextures = 0;


public:
	int getNum()
	{
		return numTextures;
	}

	static TextureManager* GetInstance();

	void LoadTexture(const char*);

	SDL_Texture* GetTexture(int);
	


};

