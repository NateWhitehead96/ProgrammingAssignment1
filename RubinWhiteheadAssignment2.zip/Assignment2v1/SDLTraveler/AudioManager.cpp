#include "AudioManager.h"

AudioManager* AudioManager::AudioMan;

AudioManager::AudioManager()
{
	Mix_OpenAudio(22050, AUDIO_S16SYS, 2, 4096);
	Mix_AllocateChannels(16);

	sMusic = Mix_LoadMUS("BGM.wav");
	sJump = Mix_LoadWAV("locked.wav");
	sFire = Mix_LoadWAV("Death.wav");

	Mix_VolumeMusic(100);
	Mix_Volume(-1, 128);	

}

AudioManager* AudioManager::GetInstance()
{
	if (AudioMan == nullptr)
	{
		AudioMan = new AudioManager;

	}
	return AudioMan;
}

void AudioManager::Music1()
{
	Mix_PlayMusic(sMusic, -1);
}
void AudioManager::Move()
{
	Mix_PlayChannel(3, sJump, 0);
}
void AudioManager::Arrive()
{
	Mix_PlayChannel(1, sFire, 0);
}

AudioManager::~AudioManager()
{
}
