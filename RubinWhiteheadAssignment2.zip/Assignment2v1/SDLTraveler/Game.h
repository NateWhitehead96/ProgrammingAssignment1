#pragma once

#include "AudioManager.h"
#include "TextureManager.h"
#include "TextManager.h"


#include <iostream>
#include <fstream>
#include "SDL.h"
#include "SDL_image.h"
#include "SDL_mixer.h"
#include "Tile.h"
#include "SDL_ttf.h"
#include "Player.h"
#include "Target.h"
#include "TextBox.h"
#include <string>
#include <ctime>
#include <vector>


using namespace std;

class Game
{
private:

	static Game* Instance;
	Game();
	bool play = true;

	// SDL stuff

	SDL_Window* pWindow = nullptr;
	SDL_Renderer* pRenderer = nullptr;



	SDL_Texture* tAsteroid;
	SDL_Texture* tGoal;
	SDL_Texture* tShip;
	SDL_Texture* tUI;

	SDL_Texture* number[8];
	SDL_Rect TextRect[8] = { {966,42,32,32},{966, 77, 32, 32},{966,142,32,32},{966, 177,32, 32},{966,242,32,32},{966, 277,32, 32},{966,342,32,32},{966, 377,32, 32}, };

	SDL_Rect UIrect = {880,0, 140,420};
	SDL_Rect UIsrc = { 0,0, 140, 420 };

	std::string num2;

	Tile* mAsteroids[21];
	Tile* tStart;

	bool hasArrived = false;

	SDL_Surface* pSurface;

	SDL_Point pGoal;
	SDL_Point pStart;

	SDL_GameController* controller1 = nullptr;
	SDL_Event event;
	SDL_RendererFlip flip = SDL_FLIP_NONE;

	int startQuad = 0;
	
	Tile* mGrid[17][22];

	/*vector<Tile*> mOpen;
	vector<Tile*> mClosed;
	vector<Tile*> mPath;*/


	Player mPlayer[5];
	Target mTarget;

	int currentShip = 0;

	SDL_Point playerCheck = {0,0};

	const char* testText = "Test" ;
	SDL_Texture* text = nullptr;

	int m_pathLength = 0;

	bool starting = true;
	bool launched = false;



public:
	static Game* GetGame();

	SDL_Renderer* GetRen()
	{
		return pRenderer;
	}

	Tile* GetTile(int x, int y);
	void Init();

	int Manhattan(SDL_Point goal, SDL_Point tile)
	{
		int x = abs((goal.x - tile.x));
	
		int y = abs((goal.y - tile.y));
		
		return (x + y);

	}

	bool GetStart()
	{
		return starting;
	}

	void endStart()
	{
		starting = false;
	}

	void findShortestPath();

	void moveShipAlong();

	int AugmentedManhattan(SDL_Point goal, SDL_Point tile, SDL_Point origin)
	{
		int x = abs((goal.x - tile.x) * 100);
		int y = abs((goal.y - tile.y) * 100);
		
		float aX = abs((origin.x - tile.x) );
		float aY = abs((origin.y - tile.y) );
		//cout << aX << endl << aY << endl;

		x = x - aX;
		y = y - aY;

		
		return (x + y);
	}

	void SetQuad(int n)
	{
		startQuad = n;
	}

	void Restart()
	{
		play = true;
	}

	void HandleEvents();

	void Update();

	void Render();

	void Clean();

	bool Over();

	bool Start();

	void Reset();

	bool endGame()
	{
		if (play == true)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	~Game();
};

