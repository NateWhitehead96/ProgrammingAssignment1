#pragma once
#include "SDL.h"
#include "SDL_image.h"

class Start
{
private:
	SDL_Surface* pSurf;
	SDL_Texture* tBG;
	SDL_Texture* ClickHere;

	SDL_Event event;

	int startQuad = 0;

	SDL_Rect Q1 = { 300, 300, 80, 60};
	SDL_Rect Q2 = { 385, 300, 80, 60 };
	SDL_Rect Q3 = { 300, 365, 80, 60 };
	SDL_Rect Q4 = { 385, 365, 80, 60 };

	SDL_Point mouse;

	bool selectScreen = false;
public:
	Start();
	void Render();

	

};

