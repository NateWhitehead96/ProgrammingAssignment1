#pragma once
#include "Player.h"
class Wizard : public Player
{
private:
	static string m_specialAttack;
	int m_specialAttAmount;
public:
	Wizard();
	~Wizard();

	// Inherited via Player
	virtual void SpecialAttack() override;
};

