#include "Wizard.h"



Wizard::Wizard()
{
}


Wizard::~Wizard()
{
}

void Wizard::SpecialAttack()
{
}
