#include "Orc.h"



Orc::Orc()
{
}


Orc::~Orc()
{
}

void Orc::Taunt()
{
}
