#pragma once
#include "Enemy.h"
class Undead : public Enemy
{
private:
	static string m_species;
	string m_taunts[5];
public:
	Undead();
	~Undead();

	// Inherited via Enemy
	virtual void Taunt() override;
};

