#pragma once
#include "GameObject.h"
#include <string>
using namespace std;

class Player : public GameObject
{
private:
	string m_name;
	int m_health;
public:
	Player();
	~Player();
	// Virtual void for player subclass
	virtual void SpecialAttack() = 0;

	// From GameObject
	virtual void NormalAttack() override;

	// Getters and setters
	string GetName()
	{
		return m_name;
	}
	void SetName(string name)
	{
		m_name = name;
	}
	int GetHealth()
	{
		return m_health;
	}
	void SetHealth(int health)
	{
		m_health = health;
	}
};

