#pragma once
#include "GameObject.h"
class Enemy : public GameObject
{
private:
	int m_health;
public:
	Enemy();
	~Enemy();
	// Virtual void for enemies
	virtual void Taunt() = 0;

	// Inherited via GameObject
	virtual void NormalAttack() override;

	// Getter and Setter
	int GetHealth()
	{
		return m_health;
	}
	void SetHealth(int h)
	{
		m_health = h;
	}
};

