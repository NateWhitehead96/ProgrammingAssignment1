#pragma once
#include "Enemy.h"
class Orc : public Enemy
{
private:
	static string m_species;
	string m_taunts[5];
public:
	Orc();
	~Orc();

	// Inherited via Enemy
	virtual void Taunt() override;
};

