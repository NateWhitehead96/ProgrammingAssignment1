#pragma once
#include "Player.h"
class Knight : public Player
{
private:
	static string m_specialAttack;
	int m_specialAttAmount;
public:
	Knight();
	~Knight();

	// Inherited via Player
	virtual void SpecialAttack() override;
};

