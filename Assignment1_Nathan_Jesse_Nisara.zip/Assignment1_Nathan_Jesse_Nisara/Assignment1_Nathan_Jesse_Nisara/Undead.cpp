#include "Undead.h"



Undead::Undead()
{
}


Undead::~Undead()
{
}

void Undead::Taunt()
{
}
