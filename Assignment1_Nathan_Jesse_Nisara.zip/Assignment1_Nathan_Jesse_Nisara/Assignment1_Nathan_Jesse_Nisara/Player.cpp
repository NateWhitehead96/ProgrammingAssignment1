#include "Player.h"



Player::Player()
{
}


Player::~Player()
{
}

void Player::NormalAttack()
{
}
