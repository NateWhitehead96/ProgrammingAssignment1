#pragma once
#include <string>
using namespace std;
class GameObject
{
public:
	GameObject();
	~GameObject();

	virtual void NormalAttack() = 0;
};

